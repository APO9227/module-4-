(function () {
'use strict';

angular.module('MenuApp', ['ui.router','data']);

})();
